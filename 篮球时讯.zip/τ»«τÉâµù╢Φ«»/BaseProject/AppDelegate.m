//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "NBAViewController.h"
#import "LeftViewController.h"
#import "WelcomeViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate

- (UIWindow *)window
{
    if (!_window) {
        _window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
    }
    return _window;
}

- (RESideMenu *)sideMenu
{
    if (!_sideMenu) {
        _sideMenu = [[RESideMenu alloc]initWithContentViewController:[NBAViewController standardNBANavi] leftMenuViewController:[LeftViewController new] rightMenuViewController:nil];
        _sideMenu.backgroundImage = [UIImage imageNamed:@"basketball_1.jpg"];
        //可以让出现菜单时不显示状态栏
        _sideMenu.menuPrefersStatusBarHidden = YES;
        //不允许菜单栏到了边缘还可以继续缩小
        _sideMenu.bouncesHorizontally = NO;
        
    }
    return _sideMenu;
}



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];
   
    NSDictionary *infoDic = [[NSBundle mainBundle]infoDictionary];
    NSString *key = @"CFBundleShortVersionString";
    NSString *currentVersion = infoDic[key];
    NSString *runVersion = [[NSUserDefaults standardUserDefaults]stringForKey:key];
    
    if (runVersion ==nil || ![runVersion isEqualToString:currentVersion]) {
        
        self.window.rootViewController = [WelcomeViewController new];
        [[NSUserDefaults standardUserDefaults]setValue:currentVersion forKey:key];
    }else{
        
        self.window.rootViewController = self.sideMenu;
    }

    return YES;
}

- (void)configGlobalUIStyle
{
    //导航栏不透明
    [[UINavigationBar appearance] setTranslucent:NO];
    //设置导航栏背景图
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"basketball_1.jpg"] forBarMetrics:UIBarMetricsDefault];
    //配置导航栏题目的样式
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSFontAttributeName:[UIFont flatFontOfSize:kNaviTitleFontSize],NSForegroundColorAttributeName:kNaviTitleColor}];
}

@end
