//
//  CBAHeadCell.m
//  BaseProject
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CBAHeadCell.h"

@implementation CBAHeadCell

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(20);
            make.left.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(300, 30));
        }];
        _titleLb.numberOfLines = 0;
    }
    return _titleLb;
}

- (UILabel *)voteCountLb {
    if(_voteCountLb == nil) {
        _voteCountLb = [[UILabel alloc] init];
        [self.contentView addSubview:_voteCountLb];
        [_voteCountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-5);
            make.bottom.mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(60, 30));
        }];
        _voteCountLb.font = [UIFont systemFontOfSize:13];
        _voteCountLb.textAlignment = NSTextAlignmentCenter;
    }
    return _voteCountLb;
}









- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
