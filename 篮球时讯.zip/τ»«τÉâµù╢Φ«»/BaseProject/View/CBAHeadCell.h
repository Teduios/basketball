//
//  CBAHeadCell.h
//  BaseProject
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CBAHeadCell : UITableViewCell

@property (nonatomic,strong)UILabel *titleLb;
@property (nonatomic,strong)UILabel *voteCountLb;


@end
