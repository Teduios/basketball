//
//  NBAVideoCell.h
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NBAVideoCell : UITableViewCell
@property (nonatomic,strong)UIImageView *imgView;
@property (nonatomic,strong)UILabel *nameLb;
@property (nonatomic,strong)UILabel *lengthLb;
@property (nonatomic,strong)UILabel *modtimeLb;
@end
