//
//  NBAVideoCell.m
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBAVideoCell.h"

@implementation NBAVideoCell

- (UIImageView *)imgView {
    if(_imgView == nil) {
        _imgView = [[UIImageView alloc] init];
        [self.contentView addSubview:_imgView];
        [_imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(5);
            make.bottom.mas_equalTo(-5);
            make.width.mas_equalTo(100);
        }];
    }
    return _imgView;
}

- (UILabel *)nameLb {
    if(_nameLb == nil) {
        _nameLb = [[UILabel alloc] init];
        [self.contentView addSubview:_nameLb];
        [_nameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.left.mas_equalTo(self.imgView.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(-5);
            make.height.mas_equalTo(50);
        }];
        _nameLb.numberOfLines = 0;
        
    }
    return _nameLb;
}

- (UILabel *)modtimeLb {
    if(_modtimeLb == nil) {
        _modtimeLb = [[UILabel alloc] init];
        [self.contentView addSubview:_modtimeLb];
        [_modtimeLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.top.mas_equalTo(self.nameLb.mas_bottom).mas_equalTo(5);
            make.bottom.mas_equalTo(-5);
            make.width.mas_equalTo(60);
        }];
        _modtimeLb.textColor = [UIColor lightGrayColor];
        _modtimeLb.textAlignment = NSTextAlignmentCenter;
        _modtimeLb.font = [UIFont systemFontOfSize:13];
        
    }
    return _modtimeLb;
}


- (UILabel *)lengthLb {
    if(_lengthLb == nil) {
        _lengthLb = [[UILabel alloc] init];
        [self.contentView addSubview:_lengthLb];
        [_lengthLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.nameLb.mas_bottom).mas_equalTo(5);
            make.bottom.mas_equalTo(-5);
            make.right.mas_equalTo(self.modtimeLb.mas_left).mas_equalTo(-5);
            make.width.mas_equalTo(self.modtimeLb.mas_width).mas_equalTo(0);
        }];
        _lengthLb.textColor = [UIColor lightGrayColor];
        _lengthLb.font = [UIFont systemFontOfSize:13];
         _lengthLb.textAlignment = NSTextAlignmentRight;
        
    }
    return _lengthLb;
}








- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
