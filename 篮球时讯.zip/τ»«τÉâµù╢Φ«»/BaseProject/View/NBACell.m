//
//  NBACell.m
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBACell.h"

@implementation NBACell

- (UIImageView *)imgView {
    if(_imgView == nil) {
        _imgView = [[UIImageView alloc] init];
        [self.contentView addSubview:_imgView];
        [_imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(10);
            make.bottom.mas_equalTo(-10);
            make.width.mas_equalTo(90);
        }];
    }
    return _imgView;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.left.mas_equalTo(self.imgView.mas_right).mas_equalTo(5);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(20);
        }];
        _titleLb.font = [UIFont systemFontOfSize:15];
        _titleLb.numberOfLines = 0;
        
    }
    return _titleLb;
}
- (UILabel *)digestLb {
    if(_digestLb == nil) {
        _digestLb = [[UILabel alloc] init];
        [self.contentView addSubview:_digestLb];
        [_digestLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(3);
            make.left.mas_equalTo(self.imgView.mas_right).mas_equalTo(5);
            make.bottom.mas_equalTo(-5);
            make.right.mas_equalTo(-5);
        }];
        _digestLb.font = [UIFont systemFontOfSize:13];
        
        _digestLb.textColor = [UIColor lightGrayColor];
        _digestLb.numberOfLines = 0;
    }
    return _digestLb;
}
- (UILabel *)voteCountLb {
    if(_voteCountLb == nil) {
        _voteCountLb = [[UILabel alloc] init];
        [self.contentView addSubview:_voteCountLb];
        [_voteCountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-8);
            make.size.mas_equalTo(CGSizeMake(70, 20));
            make.bottom.mas_equalTo(-5);
        }];
        _voteCountLb.font = [UIFont systemFontOfSize:13];
        _voteCountLb.textColor = [UIColor lightGrayColor];
        _voteCountLb.textAlignment = NSTextAlignmentRight;
        
    }
    return _voteCountLb;
}
















- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
