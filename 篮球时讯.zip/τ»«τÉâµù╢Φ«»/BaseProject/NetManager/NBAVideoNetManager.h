//
//  NBAVideoNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
//http://zhiboba.3b2o.com/videoIndex/ListJson/category/nba
@interface NBAVideoNetManager : BaseNetManager
+ (id)getNBAVideoDetail:(void(^)(id model,NSError *error))complete;
@end
