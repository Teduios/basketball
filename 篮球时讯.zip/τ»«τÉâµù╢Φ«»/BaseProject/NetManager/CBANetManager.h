//
//  CBANetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
//http://c.3g.163.com/nc/article/list/T1348649475931/0-20.html
@interface CBANetManager : BaseNetManager
+ (id)getCBADetailWithIndex:(NSInteger)index kCompletionHandle;
@end
