//
//  NBANetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "NBAModel.h"

/*http://c.3g.163.com/nc/article/list/T1348649145984/0-20.html*/
@interface NBANetManager : BaseNetManager
+ (id)getNBADetailWithIndex:(NSInteger)index kCompletionHandle;
@end
