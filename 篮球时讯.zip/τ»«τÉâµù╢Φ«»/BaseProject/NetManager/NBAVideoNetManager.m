//
//  NBAVideoNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBAVideoNetManager.h"
#import "NBAVideoModel.h"
@implementation NBAVideoNetManager
+ (id)getNBAVideoDetail:(void(^)(id model,NSError *error))complete
{
    NSString *path = @"http://zhiboba.3b2o.com/videoIndex/ListJson/category/nba";
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        complete([NBAVideoModel objectWithKeyValues:responseObj],error);
    }];
}
@end
