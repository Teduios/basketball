//
//  NBANetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBANetManager.h"

@implementation NBANetManager
+ (id)getNBADetailWithIndex:(NSInteger)index completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = [NSString stringWithFormat:@"http://c.3g.163.com/nc/article/list/T1348649145984/%ld-20.html",index];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([NBAModel objectWithKeyValues:responseObj],error);
    }];
    
}
@end
