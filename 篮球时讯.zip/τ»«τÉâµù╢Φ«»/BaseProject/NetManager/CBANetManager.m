//
//  CBANetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CBANetManager.h"
#import "CBAModel.h"
@implementation CBANetManager
+ (id)getCBADetailWithIndex:(NSInteger)index completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = [NSString stringWithFormat:@"http://c.3g.163.com/nc/article/list/T1348649475931/%ld-20.html",index];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([CBAModel objectWithKeyValues:responseObj],error);
    }];
}
@end
