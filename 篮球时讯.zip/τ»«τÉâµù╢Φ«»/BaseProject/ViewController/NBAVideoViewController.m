//
//  NBAVideoViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBAVideoViewController.h"
#import "NBAVideoViewModel.h"
#import "NBAVideoCell.h"
#import "Factory.h"
#import "NBAVideoHtmlViewController.h"
@interface NBAVideoViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NBAVideoViewModel *NBAVideoVM;
@end

@implementation NBAVideoViewController
+ (UINavigationController *)standardToNBAVideo
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NBAVideoViewController *vc = [[NBAVideoViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    
    });
    return navi;
}
- (NBAVideoViewModel *)NBAVideoVM
{
    if (!_NBAVideoVM) {
        _NBAVideoVM = [[NBAVideoViewModel alloc]init];
    }
    return _NBAVideoVM;
}
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        [_tableView registerClass:[NBAVideoCell class] forCellReuseIdentifier:@"VideoCell"];
        _tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.NBAVideoVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.header endRefreshing];
            }];
        }];
    }
    return _tableView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];

    [Factory addMenuItemToVC:self];
    [self.tableView.header beginRefreshing];
    self.title = @"精彩视频";
    
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.NBAVideoVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NBAVideoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"VideoCell"];
    [cell.imgView setImageWithURL:[_NBAVideoVM imgUrlForRow:indexPath.row]];
    cell.nameLb.text = [self.NBAVideoVM nameForRow:indexPath.row];
    cell.lengthLb.text = [self.NBAVideoVM lengthForRow:indexPath.row];
    cell.modtimeLb.text = [self.NBAVideoVM modtimeForRow:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NBAVideoHtmlViewController *vc = [[NBAVideoHtmlViewController alloc]initWithURL:[self.NBAVideoVM videoUrlForRow:indexPath.row]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
