//
//  NBASythesizeViewController.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NBASythesizeViewController : UIViewController
+ (UINavigationController *)standardToNBASythesize;
@end
