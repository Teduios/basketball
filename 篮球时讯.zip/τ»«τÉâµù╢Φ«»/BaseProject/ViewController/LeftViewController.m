//
//  LeftViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LeftViewController.h"
#import <NSString+Icons.h>
#import "NBAViewController.h"
#import "CBAViewController.h"
#import "NBASythesizeViewController.h"
#import "NBAVideoViewController.h"
@interface LeftViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSArray *Names;
@end

@implementation LeftViewController
- (NSArray *)Names
{
    return @[@"NBA新闻",@"CBA新闻",@"NBA综合信息",@"NBA精彩视频"];
}
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
        _tableView.backgroundColor = [UIColor clearColor];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(kWindowW/2, kWindowH/2));
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(20);
            make.left.mas_equalTo(0);
        }];
        //去掉分割线
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.Names.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    cell.accessoryType = 1;
    cell.textLabel.text = self.Names[indexPath.row];
    cell.backgroundColor = [UIColor clearColor];
    cell.contentView.backgroundColor = [UIColor clearColor];
    cell.textLabel.textColor = [UIColor whiteColor];
    return cell;
    
}

kRemoveCellSeparator
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.row) {
        case 0:
            [self.sideMenuViewController setContentViewController:[NBAViewController standardNBANavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];

            break;
        case 1:
            [self.sideMenuViewController setContentViewController:[CBAViewController standardToCBANavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];

            break;
        case 2:
            [self.sideMenuViewController setContentViewController:[NBASythesizeViewController standardToNBASythesize] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
            
            break;
        case 3:
            [self.sideMenuViewController setContentViewController:[NBAVideoViewController standardToNBAVideo] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
            break;
                default:
            break;
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    //必须触发一下tableView的懒加载才可以
    [self.tableView reloadData];
    FBShimmeringView *sv = [FBShimmeringView new];
    [self.view addSubview:sv];
    [sv mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(10);
        make.centerX.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(300, 40));
    }];
    UILabel *label = [UILabel new];
    label.text = @"无 兄 弟！不 篮 球！";
    label.font = [UIFont systemFontOfSize:32];
    
    sv.contentView = label;
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    label.textColor = [UIColor redColor];
    sv.shimmering = YES;
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
