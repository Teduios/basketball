//
//  NBAViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBAViewController.h"
#import "NBACell.h"
#import "NBAHeadCell.h"
#import "NBAViewModel.h"
#import "NBAHtmlViewController.h"
#import "Factory.h"
#import "TRImageView.h"

@interface NBAViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)NBAViewModel *NBAVM;
@property (nonatomic,strong)UITableView *tableView;
@end

@implementation NBAViewController

+ (UINavigationController *)standardNBANavi
{
    static UINavigationController *navi= nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NBAViewController *vc = [[NBAViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}


- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [_tableView registerClass:[NBAHeadCell class] forCellReuseIdentifier:@"HeadCell"];
        [_tableView registerClass:[NBACell class] forCellReuseIdentifier:@"Cell"];
        _tableView.tableFooterView = [UIView new];
        _tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.NBAVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.header endRefreshing];
            }];
        }];
        _tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            [self.NBAVM getMoreDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.footer endRefreshing];
            }];
        }];
    }
    return _tableView;
}

- (NBAViewModel *)NBAVM
{
    if (!_NBAVM) {
        _NBAVM = [[NBAViewModel alloc]init];
    }
    return _NBAVM;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addMenuItemToVC:self];
    [self.tableView.header beginRefreshing];
    self.title = @"NBA";
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.NBAVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        NBAHeadCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HeadCell"];
        [cell.imgView setImageWithURL:[self.NBAVM imgURLForRow:indexPath.row]];
        cell.titleLb.text = [self.NBAVM titleForRow:indexPath.row];
        return cell;
    }else{
    
    NBACell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.imgView setImageWithURL:[self.NBAVM imgURLForRow:indexPath.row]];
    cell.titleLb.text = [self.NBAVM titleForRow:indexPath.row];
    cell.digestLb.text = [self.NBAVM digestForRow:indexPath.row];
    cell.voteCountLb.text = [[self.NBAVM votecountForRow:indexPath.row] stringByAppendingString:@"跟帖"];
    
       return cell;
    }
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NBAHtmlViewController *vc = [[NBAHtmlViewController alloc]initWithUrl:[self.NBAVM urlForRow:indexPath.row]];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return 289;
    }else{
        return 90;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
