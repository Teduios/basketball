//
//  WelcomeViewController.m
//  BaseProject
//
//  Created by chendong on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WelcomeViewController.h"
#import "iCarousel.h"
#import "AppDelegate.h"
@interface WelcomeViewController ()<iCarouselDelegate,iCarouselDataSource>
//存储图片
@property (nonatomic,strong)NSArray *imageName;
@property (nonatomic,strong)iCarousel *ic;
@property (nonatomic,strong)UIPageControl *pageControl;
@end

@implementation WelcomeViewController

- (NSArray *)imageName
{
    if (!_imageName) {
        NSString *path = [[NSBundle mainBundle]pathForResource:@"lanqiu" ofType:@"bundle"];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        _imageName = [fileManager subpathsAtPath:path];
    }
    return _imageName;
}

- (iCarousel *)ic
{
    if (!_ic) {
        _ic = [iCarousel new];
        _ic.dataSource = self;
        _ic.delegate = self;
        _ic.pagingEnabled = YES;
        _ic.scrollSpeed = 1;
        _ic.bounces = NO;
    }
    return _ic;
}

- (UIPageControl *)pageControl
{
    if (!_pageControl) {
        _pageControl = [UIPageControl new];
        _pageControl.numberOfPages = self.imageName.count;
        _pageControl.currentPageIndicatorTintColor = [UIColor blueColor];
        _pageControl.pageIndicatorTintColor = [UIColor redColor];
        _pageControl.userInteractionEnabled = NO;
    }
    return _pageControl;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view addSubview:self.ic];
    [self.ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    [self.ic addSubview:self.pageControl];
    [self.pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(50);
        make.height.mas_equalTo(30);
        make.centerX.mas_equalTo(0);
        make.bottom.mas_equalTo(-20);
    }];
}

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return self.imageName.count;
}
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(nullable UIView *)view
{
    if (!view) {
        view = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH)];
        UIImageView *imageView = [UIImageView new];
        imageView.tag = 100;
        
        [view addSubview:imageView];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *imageView = (UIImageView *)[view viewWithTag:100];
    NSString *path = [[NSBundle mainBundle]pathForResource:@"lanqiu" ofType:@"bundle"];
    path = [path stringByAppendingPathComponent:self.imageName[index]];
    imageView.image = [UIImage imageWithContentsOfFile:path];
    return view;
}
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel
{
    self.pageControl.currentPage = carousel.currentItemIndex;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index
{
    if (index == 3) {
        UIWindow *window = [[UIApplication sharedApplication]keyWindow];
        window.rootViewController = [AppDelegate new].sideMenu;
    }
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
