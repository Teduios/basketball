//
//  CBAModel.m
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CBAModel.h"

@implementation CBAModel


+ (NSDictionary *)objectClassInArray{
    return @{@"T1348649475931" : [CBADetailModel class]};
}
@end
@implementation CBADetailModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"temp":@"template"};
}

@end


