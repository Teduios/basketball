//
//  NBAVideoModel.m
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBAVideoModel.h"

@implementation NBAVideoModel


+ (NSDictionary *)objectClassInArray{
    return @{@"videos" : [Videos class]};
}
@end
@implementation Videos

+ (NSDictionary *)objectClassInArray{
    return @{@"tags" : [VideosTags class]};
}

+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"ID":@"id"};
}
@end


@implementation VideosImginfo

@end


@implementation VideosTags
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"ID":@"id"};
}

@end


