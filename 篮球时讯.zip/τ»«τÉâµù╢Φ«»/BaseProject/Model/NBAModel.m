//
//  NBAModel.m
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBAModel.h"

@implementation NBAModel


+ (NSDictionary *)objectClassInArray{
    return @{@"T1348649145984" : [NBADetailModel class]};
}
@end
@implementation NBADetailModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"temp":@"template"};
}
@end


