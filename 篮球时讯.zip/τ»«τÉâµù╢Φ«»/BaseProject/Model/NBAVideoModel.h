//
//  NBAVideoModel.h
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class Videos,VideosImginfo,VideosTags;
@interface NBAVideoModel : BaseModel

@property (nonatomic, strong) NSArray *recommends;

@property (nonatomic, strong) NSArray<Videos *> *videos;

@end
@interface Videos : NSObject

@property (nonatomic, copy) NSString *modtime_src;

@property (nonatomic, copy) NSString *pathfile;

@property (nonatomic, copy) NSString *bname;

@property (nonatomic, copy) NSString *rank;

@property (nonatomic, copy) NSString *shortname;

@property (nonatomic, strong) VideosImginfo *imgInfo;

@property (nonatomic, copy) NSString *bjc;

@property (nonatomic, copy) NSString *sport;

@property (nonatomic, copy) NSString *blength;

@property (nonatomic, copy) NSString *mobileDownloadUrl;

@property (nonatomic, copy) NSString *hits;

@property (nonatomic, strong) NSArray<VideosTags *> *tags;

@property (nonatomic, assign) NSInteger imp;

@property (nonatomic, copy) NSString *mobileImgUrl;

@property (nonatomic, copy) NSString *daily_hits;

@property (nonatomic, copy) NSString *cover_img;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *bury;

@property (nonatomic, copy) NSString *modtime;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *length;

@property (nonatomic, copy) NSString *weekly_hits;

@property (nonatomic, copy) NSString *addtime;

@property (nonatomic, copy) NSString *v_count;

@property (nonatomic, copy) NSString *league;

@property (nonatomic, strong) NSArray<NSString *> *defaultMobileUrl;

@property (nonatomic, copy) NSString *imgUrl;

@property (nonatomic, copy) NSString *dig;

@property (nonatomic, assign) NSInteger star;

@property (nonatomic, copy) NSString *defaultMobileLink;

@property (nonatomic, copy) NSString *defaultShowUrl;

@end

@interface VideosImginfo : NSObject

@property (nonatomic, copy) NSString *height;

@property (nonatomic, copy) NSString *dynamic;

@property (nonatomic, copy) NSString *mime;

@property (nonatomic, copy) NSString *width;

@property (nonatomic, copy) NSString *size;

@property (nonatomic, copy) NSString *sid;

@property (nonatomic, copy) NSString *extension;

@end

@interface VideosTags : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *bjc;

@end

