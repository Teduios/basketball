//
//  NBAVideoViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface NBAVideoViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;


- (NSURL *)imgUrlForRow:(NSInteger)row;
- (NSString *)nameForRow:(NSInteger)row;
- (NSString *)lengthForRow:(NSInteger)row;
- (NSString *)modtimeForRow:(NSInteger)row;
- (NSURL *)videoUrlForRow:(NSInteger)row;

@end
