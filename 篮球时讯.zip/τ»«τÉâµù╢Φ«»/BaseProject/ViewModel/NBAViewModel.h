//
//  NBAViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "NBANetManager.h"
@interface NBAViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;
@property (nonatomic)NSInteger index;

- (NSString *)digestForRow:(NSInteger)row;
- (NSString *)titleForRow:(NSInteger)row;
- (NSString *)votecountForRow:(NSInteger)row;
- (NSURL *)imgURLForRow:(NSInteger)row;
- (NSURL *)urlForRow:(NSInteger)row;

@end
