//
//  NBAVideoViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBAVideoViewModel.h"
#import "NBAVideoModel.h"
#import "NBAVideoNetManager.h"
@implementation NBAVideoViewModel
- (NSInteger)rowNumber
{
    return self.dataArr.count;
}

- (Videos *)VideoDetailForRow:(NSInteger)row
{
    return self.dataArr[row];
}

- (NSURL *)imgUrlForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self VideoDetailForRow:row].imgUrl];
}

- (NSString *)nameForRow:(NSInteger)row
{
    return [self VideoDetailForRow:row].name;
}

- (NSString *)lengthForRow:(NSInteger)row
{
    return [self VideoDetailForRow:row].length;
}

- (NSString *)modtimeForRow:(NSInteger)row
{
    return [self VideoDetailForRow:row].modtime;
}

- (NSURL *)videoUrlForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self VideoDetailForRow:row].defaultMobileLink];
}

- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [NBAVideoNetManager getNBAVideoDetail:^(NBAVideoModel *model, NSError *error) {
        self.dataArr = [model.videos mutableCopy];
        completionHandle(error);
    }];
}
@end
