//
//  CBAViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CBAViewModel.h"
#import "CBANetManager.h"
#import "CBAModel.h"
@implementation CBAViewModel
- (NSInteger)rowNumber
{
    return self.dataArr.count;
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    _index = 0;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    _index += 20;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [CBANetManager getCBADetailWithIndex:_index completionHandle:^(CBAModel *model, NSError *error) {
        if (_index == 0) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.T1348649475931];
        completionHandle(error);
    }];
}
- (CBADetailModel *)modelDetailForRow:(NSInteger)row
{
    return self.dataArr[row];
}
- (NSString *)titleForRow:(NSInteger)row
{
    return [self modelDetailForRow:row].title;
}
- (NSString *)voteCountForRow:(NSInteger)row
{
    return @([self modelDetailForRow:row].votecount).stringValue;
}
- (NSURL *)imgUrlForRow:(NSInteger)row
{
    NSString *path = [self modelDetailForRow:row].imgsrc;
    return [NSURL URLWithString:path];
}
- (NSURL *)urlForRow:(NSInteger)row
{
    NSString *path = [self modelDetailForRow:row].url_3w;
    return [NSURL URLWithString:path];
}
@end
