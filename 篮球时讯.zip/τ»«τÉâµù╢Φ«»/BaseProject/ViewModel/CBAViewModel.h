//
//  CBAViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface CBAViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;
@property (nonatomic)NSInteger index;

- (NSString *)titleForRow:(NSInteger)row;
- (NSString *)voteCountForRow:(NSInteger)row;
- (NSURL *)imgUrlForRow:(NSInteger)row;
- (NSURL *)urlForRow:(NSInteger)row;
@end
