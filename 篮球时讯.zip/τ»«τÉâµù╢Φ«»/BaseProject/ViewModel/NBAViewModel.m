//
//  NBAViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NBAViewModel.h"

@implementation NBAViewModel
- (NSInteger)rowNumber
{
    return self.dataArr.count;
}

- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    _index = 0;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    _index += 20;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [NBANetManager getNBADetailWithIndex:_index completionHandle:^(NBAModel *model, NSError *error) {
        if (_index == 0) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.T1348649145984];
        completionHandle(error);
    }];
}
- (NBADetailModel *)modelDetailForRow:(NSInteger)row
{
    return self.dataArr[row];
}
- (NSString *)digestForRow:(NSInteger)row
{
    return [self modelDetailForRow:row].digest;
}
- (NSURL *)imgURLForRow:(NSInteger)row
{
    NSString *path = [self modelDetailForRow:row].imgsrc;
    return [NSURL URLWithString:path];
}
- (NSString *)votecountForRow:(NSInteger)row
{
    return @([self modelDetailForRow:row].votecount ).stringValue;
}
- (NSString *)titleForRow:(NSInteger)row
{
    return  [self modelDetailForRow:row].title;
}
- (NSURL *)urlForRow:(NSInteger)row
{
    NSString *path = [self modelDetailForRow:row].url_3w;
    return [NSURL URLWithString:path];
}
@end
